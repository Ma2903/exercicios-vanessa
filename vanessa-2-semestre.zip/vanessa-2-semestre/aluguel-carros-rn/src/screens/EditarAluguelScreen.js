import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, ActivityIndicator, ScrollView } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { AluguelService } from '../services/AluguelService';
import { ClienteService } from '../services/ClienteService';
import { VeiculoService } from '../services/VeiculoService';
import { ContratoService } from '../services/ContratoService';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Picker } from '@react-native-picker/picker';

const EditarAluguelScreen = ({ route, navigation }) => {
  const { id } = route.params;
  const [clientes, setClientes] = useState([]);
  const [veiculos, setVeiculos] = useState([]);
  const [contratos, setContratos] = useState([]);
  const [cliente, setCliente] = useState('');
  const [carro, setCarro] = useState('');
  const [idContrato, setIdContrato] = useState('');
  const [dataInicio, setDataInicio] = useState(new Date());
  const [dataFim, setDataFim] = useState(new Date());
  const [showDatePickerInicio, setShowDatePickerInicio] = useState(false);
  const [showDatePickerFim, setShowDatePickerFim] = useState(false);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const loadData = async () => {
      try {
        const clientesResponse = await ClienteService.getAll();
        const veiculosResponse = await VeiculoService.getAll();
        const contratosResponse = await ContratoService.getAll();
        setClientes(clientesResponse);
        setVeiculos(veiculosResponse);
        setContratos(contratosResponse);

        const aluguelResponse = await AluguelService.getById(id);
        setCliente(aluguelResponse.id_cliente);
        setCarro(aluguelResponse.id_veiculo);
        setIdContrato(aluguelResponse.id_contrato);
        setDataInicio(new Date(aluguelResponse.data_inicio));
        setDataFim(new Date(aluguelResponse.data_fim));
        setLoading(false);
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
        Alert.alert('Erro', 'Não foi possível carregar os dados do aluguel.');
        setLoading(false);
      }
    };

    loadData();
  }, [id]);

  const handleSubmit = async () => {
    if (!cliente || !carro || !idContrato || !dataInicio || !dataFim) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos.');
      return;
    }

    setIsSubmitting(true);

    try {
      await AluguelService.update(id, {
        id_cliente: cliente,
        id_veiculo: carro,
        id_contrato: idContrato,
        data_inicio: dataInicio.toISOString().split('T')[0],
        data_fim: dataFim.toISOString().split('T')[0],
      });
      Alert.alert(
        'Sucesso',
        'Aluguel atualizado com sucesso!',
        [{ text: 'OK', onPress: () => navigation.navigate('ListaAlugueis') }]
      );
    } catch (error) {
      console.error('Erro ao atualizar aluguel:', error);
      Alert.alert('Erro', 'Erro ao atualizar aluguel. Verifique os dados e tente novamente.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDateChangeInicio = (event, selectedDate) => {
    setShowDatePickerInicio(false);
    if (selectedDate) {
      setDataInicio(selectedDate);
    }
  };

  const handleDateChangeFim = (event, selectedDate) => {
    setShowDatePickerFim(false);
    if (selectedDate) {
      setDataFim(selectedDate);
    }
  };

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#3498db" />
        <Text style={styles.loadingText}>Carregando dados do aluguel...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.scrollContainer}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Editar Aluguel</Text>
        </View>

        <View style={styles.formContainer}>
          <View style={styles.inputGroup}>
            <Text style={styles.label}>Cliente:</Text>
            <Picker
              selectedValue={cliente}
              onValueChange={(itemValue) => setCliente(itemValue)}
              style={styles.picker}
            >
              <Picker.Item label="Selecione um cliente" value="" />
              {clientes.map((item) => (
                <Picker.Item key={item.id} label={item.nome} value={item.id} />
              ))}
            </Picker>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Carro:</Text>
            <Picker
              selectedValue={carro}
              onValueChange={(itemValue) => setCarro(itemValue)}
              style={styles.picker}
            >
              <Picker.Item label="Selecione um carro" value="" />
              {veiculos.map((item) => (
                <Picker.Item key={item.id} label={item.modelo} value={item.id} />
              ))}
            </Picker>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Contrato:</Text>
            <Picker
              selectedValue={idContrato}
              onValueChange={(itemValue) => setIdContrato(itemValue)}
              style={styles.picker}
            >
              <Picker.Item label="Selecione um contrato" value="" />
              {contratos.map((item) => (
                <Picker.Item key={item.id} label={item.tipo} value={item.id} />
              ))}
            </Picker>
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Data de Início:</Text>
            <TouchableOpacity
              style={styles.dateButton}
              onPress={() => setShowDatePickerInicio(true)}
            >
              <Ionicons name="calendar" size={20} color="#4a90e2" />
              <Text style={styles.dateButtonText}>
                {dataInicio.toLocaleDateString('pt-BR')}
              </Text>
            </TouchableOpacity>
            {showDatePickerInicio && (
              <DateTimePicker
                value={dataInicio}
                mode="date"
                display="default"
                onChange={handleDateChangeInicio}
              />
            )}
          </View>

          <View style={styles.inputGroup}>
            <Text style={styles.label}>Data de Fim:</Text>
            <TouchableOpacity
              style={styles.dateButton}
              onPress={() => setShowDatePickerFim(true)}
            >
              <Ionicons name="calendar" size={20} color="#4a90e2" />
              <Text style={styles.dateButtonText}>
                {dataFim.toLocaleDateString('pt-BR')}
              </Text>
            </TouchableOpacity>
            {showDatePickerFim && (
              <DateTimePicker
                value={dataFim}
                mode="date"
                display="default"
                onChange={handleDateChangeFim}
              />
            )}
          </View>

          <TouchableOpacity style={styles.submitButton} onPress={handleSubmit} disabled={isSubmitting}>
            <Ionicons name="checkmark-circle" size={20} color="white" />
            <Text style={styles.submitButtonText}>
              {isSubmitting ? 'Atualizando...' : 'Atualizar Aluguel'}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.cancelButton} onPress={() => navigation.goBack()}>
            <Ionicons name="close-circle" size={20} color="white" />
            <Text style={styles.cancelButtonText}>Cancelar</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 15,
  },
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    backgroundColor: '#4a90e2',
    padding: 20,
    alignItems: 'center',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    elevation: 5,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
  },
  formContainer: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    elevation: 3,
  },
  inputGroup: {
    marginBottom: 15,
  },
  label: {
    fontSize: 14,
    fontWeight: 'bold',
    marginBottom: 5,
    color: '#333',
  },
  picker: {
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 10,
    fontSize: 14,
  },
  dateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f9f9f9',
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 8,
    padding: 10,
  },
  dateButtonText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 10,
  },
  submitButton: {
    flexDirection: 'row',
    backgroundColor: '#2c3e50',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
    elevation: 3,
  },
  submitButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 14,
    marginLeft: 10,
  },
  cancelButton: {
    flexDirection: 'row',
    backgroundColor: '#95a5a6',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 3,
  },
  cancelButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 14,
    marginLeft: 10,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: '#666',
  },
});

export default EditarAluguelScreen;