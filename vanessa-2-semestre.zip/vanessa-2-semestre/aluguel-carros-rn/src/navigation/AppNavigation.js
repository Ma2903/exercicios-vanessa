import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons'; // Certifique-se de ter o pacote @expo/vector-icons instalado

// Importação das telas
import HomeScreen from '../screens/HomeScreen';
import ClientesListScreen from '../screens/ClientesListScreen';
import CadastrarClienteScreen from '../screens/CadastrarClienteScreen';
import EditarClienteScreen from '../screens/EditarClienteScreen';
import VeiculosListScreen from '../screens/VeiculosListScreen';
import CadastrarVeiculoScreen from '../screens/CadastrarVeiculoScreen';
import EditarVeiculoScreen from '../screens/EditarVeiculoScreen';
import AlugueisListScreen from '../screens/AlugueisListScreen';
import CadastrarAluguelScreen from '../screens/CadastrarAluguelScreen';
import EditarAluguelScreen from '../screens/EditarAluguelScreen';
import ContratosListScreen from '../screens/ContratosListScreen';
import CadastrarContratoScreen from '../screens/CadastrarContratoScreen';
import EditarContratoScreen from '../screens/EditarContratoScreen';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Navegação principal com tabs
function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = 'home';
          } else if (route.name === 'Clientes') {
            iconName = 'people';
          } else if (route.name === 'Veículos') {
            iconName = 'car';
          } else if (route.name === 'Contratos') {
            iconName = 'document';
          } else if (route.name === 'Aluguéis') {
            iconName = 'calendar';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#4a90e2',
        tabBarInactiveTintColor: '#999',
        tabBarStyle: { backgroundColor: '#f5f5f5' },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Clientes" component={ClientesStack} />
      <Tab.Screen name="Veículos" component={VeiculosStack} />
      <Tab.Screen name="Contratos" component={ContratosStack} />
      <Tab.Screen name="Aluguéis" component={AlugueisStack} />
    </Tab.Navigator>
  );
}

// Stack para Clientes
function ClientesStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="ListaClientes" component={ClientesListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="CadastrarCliente" component={CadastrarClienteScreen} />
      <Stack.Screen name="EditarCliente" component={EditarClienteScreen} />
    </Stack.Navigator>
  );
}

// Stack para Veículos
function VeiculosStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="ListaVeiculos" component={VeiculosListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="CadastrarVeiculo" component={CadastrarVeiculoScreen} />
      <Stack.Screen name="EditarVeiculo" component={EditarVeiculoScreen} />
    </Stack.Navigator>
  );
}

// Stack para Contratos
function ContratosStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="ListaContratos" component={ContratosListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="CadastrarContrato" component={CadastrarContratoScreen} />
      <Stack.Screen name="EditarContrato" component={EditarContratoScreen} />
    </Stack.Navigator>
  );
}

// Stack para Aluguéis
function AlugueisStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="ListaAlugueis" component={AlugueisListScreen} options={{ headerShown: false }} />
      <Stack.Screen name="CadastrarAluguel" component={CadastrarAluguelScreen} />
      <Stack.Screen name="EditarAluguel" component={EditarAluguelScreen} />
    </Stack.Navigator>
  );
}

// Navegação principal
export default function AppNavigation() {
  return (
    <NavigationContainer>
      <MainTabs />
    </NavigationContainer>
  );
}

