import axios from 'axios';

 const API_URL = 'http://192.168.0.104:3005';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // Timeout de 10 segundos
});

// Interceptor para tratamento global de erros
api.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error('API Error:', error);
    
    // Você pode adicionar lógica personalizada de tratamento de erro aqui
    // Por exemplo, tratamento específico para erros de rede ou autenticação
    
    if (error.response) {
      // O servidor respondeu com um status de erro
      console.log('Status:', error.response.status);
      console.log('Data:', error.response.data);
    } else if (error.request) {
      // A requisição foi feita mas não houve resposta
      console.log('Erro de conexão. Verifique sua internet ou se o servidor está online.');
    } else {
      // Algo aconteceu na configuração da requisição
      console.log('Erro:', error.message);
    }
    
    return Promise.reject(error);
  }
);

export default api;

