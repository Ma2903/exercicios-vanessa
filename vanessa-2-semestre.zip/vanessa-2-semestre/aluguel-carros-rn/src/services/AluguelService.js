import api from '../services/api';

// Serviço para gerenciar aluguéis
export const AluguelService = {
  // Buscar todos os aluguéis
  getAll: async () => {
    try {
      const response = await api.get('/alugueis');
      return response.data;
    } catch (error) {
      console.error('Erro ao buscar aluguéis:', error);
      throw error;
    }
  },

  // Buscar aluguel por ID
  getById: async (id) => {
    try {
      const response = await api.get(`/alugueis/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Erro ao buscar aluguel ${id}:`, error);
      throw error;
    }
  },

  // Criar novo aluguel
  create: async (aluguelData) => {
    try {
      const response = await api.post('/alugueis', aluguelData);
      return response.data;
    } catch (error) {
      console.error('Erro ao criar aluguel:', error);
      throw error;
    }
  },

  // Atualizar aluguel existente
  update: async (id, aluguelData) => {
    try {
      const response = await api.put(`/alugueis/${id}`, aluguelData);
      return response.data;
    } catch (error) {
      console.error(`Erro ao atualizar aluguel ${id}:`, error);
      throw error;
    }
  },

  // Excluir aluguel
  delete: async (id) => {
    try {
      const response = await api.delete(`/alugueis/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Erro ao excluir aluguel ${id}:`, error);
      throw error;
    }
  }
};

