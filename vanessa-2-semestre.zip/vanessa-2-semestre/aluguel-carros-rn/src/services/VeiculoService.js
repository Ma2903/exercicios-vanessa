import api from '../services/api';

// Serviço para gerenciar veículos
export const VeiculoService = {
  // Buscar todos os veículos
  getAll: async () => {
    try {
      const response = await api.get('/veiculos');
      return response.data;
    } catch (error) {
      console.error('Erro ao buscar veículos:', error);
      throw error;
    }
  },

  // Buscar veículo por ID
  getById: async (id) => {
    try {
      const response = await api.get(`/veiculos/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Erro ao buscar veículo ${id}:`, error);
      throw error;
    }
  },

  // Criar novo veículo
  create: async (veiculoData) => {
    try {
      const response = await api.post('/veiculos', veiculoData);
      return response.data;
    } catch (error) {
      console.error('Erro ao criar veículo:', error);
      throw error;
    }
  },

  // Atualizar veículo existente
  update: async (id, veiculoData) => {
    try {
      const response = await api.put(`/veiculos/${id}`, veiculoData);
      return response.data;
    } catch (error) {
      console.error(`Erro ao atualizar veículo ${id}:`, error);
      throw error;
    }
  },

  // Excluir veículo
  delete: async (id) => {
    try {
      const response = await api.delete(`/veiculos/${id}`);
      return response.data;
    } catch (error) {
      console.error(`Erro ao excluir veículo ${id}:`, error);
      throw error;
    }
  }
};

