import { ClienteService } from './ClienteService';
import { VeiculoService } from './VeiculoService';
import { ContratoService } from './ContratoService';
import { AluguelService } from './AluguelService';

// Exporta todos os serviços em um único objeto
export {
  ClienteService,
  VeiculoService,
  ContratoService,
  AluguelService
};

