# Instruções para Testar o Aplicativo React Native

Este documento fornece instruções para testar o aplicativo React Native de Aluguel de Carros.

## Pré-requisitos

1. Node.js e npm instalados
2. Expo CLI instalado globalmente (`npm install -g expo-cli`)
3. Backend Node.js configurado e em execução
4. Banco de dados MySQL configurado com o esquema `aluguel_carros`
5. Emulador Android/iOS ou dispositivo físico para teste

## Configuração do Ambiente

### 1. Configurar o Backend

Siga as instruções no arquivo `backend-config.md` para configurar e executar o backend Node.js.

### 2. Configurar o Endereço IP

Edite o arquivo `src/services/api.js` e atualize o valor de `API_URL` com o endereço IP correto:

- Para emulador Android: `http://10.0.2.2:3000`
- Para iOS Simulator: `http://localhost:3000`
- Para dispositivo físico: `http://SEU_IP_LOCAL:3000` (substitua SEU_IP_LOCAL pelo IP da sua máquina na rede)

## Executando o Aplicativo

1. Navegue até o diretório do projeto React Native:
   ```
   cd aluguel-carros-rn
   ```

2. Instale as dependências:
   ```
   npm install
   ```
   ou
   ```
   yarn install
   ```

3. Inicie o aplicativo:
   ```
   npm start
   ```
   ou
   ```
   yarn start
   ```

4. Siga as instruções no terminal para abrir o aplicativo no emulador ou dispositivo físico:
   - Pressione `a` para abrir no emulador Android
   - Pressione `i` para abrir no simulador iOS
   - Escaneie o QR code com o aplicativo Expo Go em um dispositivo físico

## Testando o Aplicativo

1. Ao abrir o aplicativo, você verá a tela inicial com os menus principais.
2. Navegue até a aba "Teste" para verificar a conexão com a API.
3. Teste as funcionalidades de Clientes:
   - Visualizar lista de clientes
   - Cadastrar novo cliente
   - Editar cliente existente
   - Excluir cliente

## Solução de Problemas

### Erro de Conexão com a API

Se você encontrar erros de conexão com a API, verifique:

1. Se o backend está em execução
2. Se o endereço IP configurado no `api.js` está correto
3. Se não há firewall bloqueando a conexão
4. Se o dispositivo/emulador e o servidor estão na mesma rede

### Erros de Renderização

Se encontrar problemas de renderização:

1. Reinicie o servidor Expo (`npm start`)
2. Limpe o cache do aplicativo
3. Reinstale as dependências (`npm install`)

