# Aluguel de Carros - Aplicativo React Native

Este projeto é uma conversão do sistema web de Aluguel de Carros (React/Node.js/MySQL) para um aplicativo móvel utilizando React Native.

## Estrutura do Projeto

O projeto está organizado da seguinte forma:

```
aluguel-carros-rn/
├── src/
│   ├── assets/         # Imagens, ícones e outros recursos
│   ├── components/     # Componentes reutilizáveis
│   ├── navigation/     # Configuração de navegação
│   ├── screens/        # Telas do aplicativo
│   └── services/       # Serviços para comunicação com a API
├── App.js              # Ponto de entrada do aplicativo
├── app.json            # Configuração do Expo
├── package.json        # Dependências do projeto
└── README.md           # Documentação
```

## Tecnologias Utilizadas

- **React Native**: Framework para desenvolvimento de aplicativos móveis
- **Expo**: Plataforma para facilitar o desenvolvimento React Native
- **React Navigation**: Biblioteca para navegação entre telas
- **Axios**: Cliente HTTP para comunicação com a API
- **Node.js/Express**: Backend (mantido do projeto original)
- **MySQL**: Banco de dados (mantido do projeto original)

## Funcionalidades

O aplicativo mantém as mesmas funcionalidades do sistema web original:

1. **Gestão de Clientes**:
   - Listar todos os clientes
   - Cadastrar novo cliente
   - Editar cliente existente
   - Excluir cliente

2. **Gestão de Veículos**:
   - Listar todos os veículos
   - Cadastrar novo veículo
   - Editar veículo existente
   - Excluir veículo

3. **Gestão de Contratos**:
   - Listar todos os contratos
   - Cadastrar novo contrato
   - Editar contrato existente
   - Excluir contrato

4. **Gestão de Aluguéis**:
   - Listar todos os aluguéis
   - Cadastrar novo aluguel
   - Editar aluguel existente
   - Excluir aluguel

## Instalação e Execução

### Pré-requisitos

- Node.js e npm instalados
- Expo CLI instalado globalmente (`npm install -g expo-cli`)
- Backend Node.js configurado e em execução
- Banco de dados MySQL configurado

### Passos para Instalação

1. Clone o repositório:
   ```
   git clone <url-do-repositorio>
   cd aluguel-carros-rn
   ```

2. Instale as dependências:
   ```
   npm install
   ```
   ou
   ```
   yarn install
   ```

3. Configure o endereço IP do backend no arquivo `src/services/api.js`.

4. Inicie o aplicativo:
   ```
   npm start
   ```
   ou
   ```
   yarn start
   ```

5. Siga as instruções no terminal para abrir o aplicativo no emulador ou dispositivo físico.

## Configuração do Backend

Para configurar o backend, consulte o arquivo `backend-config.md` que contém instruções detalhadas.

## Testes

Para instruções sobre como testar o aplicativo, consulte o arquivo `TESTING.md`.

## Diferenças em Relação ao Projeto Web

- Interface adaptada para dispositivos móveis
- Navegação baseada em tabs e stack
- Componentes nativos em vez de HTML/CSS
- Estilos usando StyleSheet em vez de Tailwind CSS

## Próximos Passos

- Implementar autenticação de usuários
- Adicionar notificações push
- Melhorar a experiência offline
- Implementar testes automatizados

