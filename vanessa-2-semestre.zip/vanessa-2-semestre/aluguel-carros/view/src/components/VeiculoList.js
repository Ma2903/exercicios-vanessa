import React, { useEffect, useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faArrowLeft, faCar, faEdit, faTrash, faPlus } from '@fortawesome/free-solid-svg-icons';

// Importa o SweetAlert2 pelo CDN
const Swal = window.Swal;

const VeiculoList = () => {
  const [veiculos, setVeiculos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    api.get('/veiculos')
      .then((response) => {
        setVeiculos(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Erro ao buscar veículos:', error);
        setError('Não foi possível carregar a lista de veículos.');
        setLoading(false);
      });
  }, []);

  const handleDelete = (id) => {
    Swal.fire({
      title: 'Tem certeza?',
      text: 'Você não poderá desfazer esta ação!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Sim, excluir!',
      cancelButtonText: 'Cancelar',
    }).then((result) => {
      if (result.isConfirmed) {
        api.delete(`/veiculos/${id}`)
          .then(() => {
            setVeiculos(veiculos.filter((veiculo) => veiculo.id !== id));
            Swal.fire('Excluído!', 'O veículo foi excluído com sucesso.', 'success');
          })
          .catch((error) => {
            console.error('Erro ao excluir veículo:', error);
            Swal.fire('Erro!', 'Não foi possível excluir o veículo.', 'error');
          });
      }
    });
  };

  if (loading) {
    return <p className="p-4 text-center text-gray-500">Carregando veículos...</p>;
  }

  if (error) {
    return <p className="p-4 text-center text-red-500">{error}</p>;
  }

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      {/* Botão de Voltar */}
      <div className="flex justify-start mb-6">
        <button
          onClick={() => navigate('/')}
          className="flex items-center px-4 py-2 bg-gray-900 text-white rounded hover:bg-gray-700 transition duration-300"
        >
          <FontAwesomeIcon icon={faArrowLeft} className="mr-2" />
          Voltar para Home
        </button>
      </div>

      {/* Título */}
      <h1 className="text-4xl font-extrabold text-gray-800 mb-8 text-center flex items-center justify-center">
        <FontAwesomeIcon icon={faCar} className="mr-3 text-gray-700" />
        Lista de Veículos
      </h1>

      {/* Botão de Cadastrar Veículo */}
      <div className="flex justify-end mb-6">
        <button
          onClick={() => navigate('/CadastrarVeiculo')}
          className="flex items-center px-6 py-3 bg-gray-900 text-white rounded hover:bg-gray-700 transition duration-300"
        >
          <FontAwesomeIcon icon={faPlus} className="mr-2" />
          Cadastrar Veículo
        </button>
      </div>

      {/* Lista de Veículos */}
      {veiculos.length === 0 ? (
        <p className="text-center text-gray-500">Nenhum veículo encontrado.</p>
      ) : (
        <ul className="space-y-6">
          {veiculos.map((veiculo) => (
            <li
              key={veiculo.id}
              className="p-6 bg-white rounded-lg shadow-lg hover:shadow-2xl transition duration-300"
            >
              <p className="mb-4 text-lg text-gray-800">
                <strong>Modelo:</strong> {veiculo.modelo}
              </p>
              <p className="mb-4 text-lg text-gray-800">
                <strong>Marca:</strong> {veiculo.marca}
              </p>
              <p className="mb-6 text-lg text-gray-800">
                <strong>Ano:</strong> {veiculo.ano}
              </p>
              <p className="mb-6 text-lg text-gray-800">
                <strong>Placa:</strong> {veiculo.placa}
              </p>
              <div className="flex space-x-4">
                <button
                  onClick={() => navigate(`/editarVeiculo/${veiculo.id}`)}
                  className="flex items-center px-6 py-3 bg-gray-900 text-white rounded hover:bg-gray-700 transition duration-300"
                >
                  <FontAwesomeIcon icon={faEdit} className="mr-2" />
                  Editar
                </button>
                <button
                  onClick={() => handleDelete(veiculo.id)}
                  className="flex items-center px-6 py-3 bg-red-500 text-white rounded hover:bg-red-600 transition duration-300"
                >
                  <FontAwesomeIcon icon={faTrash} className="mr-2" />
                  Excluir
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default VeiculoList;