import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { FaCalculator, FaRuler, FaExchangeAlt, FaMoneyBill, FaEllipsisH } from 'react-icons/fa';
import BasicCalculations from './components/BasicCalculations';
import GeometryCalculations from './components/GeometryCalculations';
import ConversionCalculations from './components/ConversionCalculations';
import FinanceCalculations from './components/FinanceCalculations';
import OtherCalculations from './components/OtherCalculations';

function App() {
  const renderMenu = () => (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-blue-400 to-green-400 text-white">
      <h1 className="text-4xl font-bold mb-8">Calculadora React</h1>
      <div className="flex flex-col gap-4">
        <Link
          to="/basic"
          className="flex items-center justify-center bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          <FaCalculator className="mr-2" /> Cálculos Básicos
        </Link>
        <Link
          to="/geometry"
          className="flex items-center justify-center bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          <FaRuler className="mr-2" /> Geometria
        </Link>
        <Link
          to="/conversions"
          className="flex items-center justify-center bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          <FaExchangeAlt className="mr-2" /> Conversões
        </Link>
        <Link
          to="/finance"
          className="flex items-center justify-center bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          <FaMoneyBill className="mr-2" /> Finanças
        </Link>
        <Link
          to="/other"
          className="flex items-center justify-center bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        >
          <FaEllipsisH className="mr-2" /> Outros Cálculos
        </Link>
      </div>
    </div>
  );

  return (
    <Router>
      <Routes>
        <Route path="/" element={renderMenu()} />
        <Route path="/basic" element={<BasicCalculations onBack={() => {}} />} />
        <Route path="/geometry" element={<GeometryCalculations onBack={() => {}} />} />
        <Route path="/conversions" element={<ConversionCalculations onBack={() => {}} />} />
        <Route path="/finance" element={<FinanceCalculations onBack={() => {}} />} />
        <Route path="/other" element={<OtherCalculations onBack={() => {}} />} />
      </Routes>
    </Router>
  );
}

export default App;