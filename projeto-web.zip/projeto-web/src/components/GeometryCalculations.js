import React, { useState } from 'react';
import { FaCircle, FaSquare, FaPlay, FaEquals } from 'react-icons/fa';

const GeometryCalculations = ({ onBack }) => {
  const [activeCalculation, setActiveCalculation] = useState(null);
  const [values, setValues] = useState([]);
  const [result, setResult] = useState('');

  const calculations = {
    areaCircle: {
      label: 'Área do Círculo',
      icon: <FaCircle className="text-blue-500 text-2xl" />,
      inputs: ['Raio'],
      calculate: (values) => (Math.PI * Math.pow(values[0], 2)).toFixed(2),
    },
    perimeterCircle: {
      label: 'Perímetro do Círculo',
      icon: <FaCircle className="text-blue-500 text-2xl" />,
      inputs: ['Raio'],
      calculate: (values) => (2 * Math.PI * values[0]).toFixed(2),
    },
    areaRectangle: {
      label: 'Área do Retângulo',
      icon: <FaSquare className="text-blue-500 text-2xl" />,
      inputs: ['Largura', 'Altura'],
      calculate: (values) => (values[0] * values[1]).toFixed(2),
    },
    perimeterRectangle: {
      label: 'Perímetro do Retângulo',
      icon: <FaSquare className="text-blue-500 text-2xl" />,
      inputs: ['Largura', 'Altura'],
      calculate: (values) => (2 * (values[0] + values[1])).toFixed(2),
    },
    areaTriangle: {
      label: 'Área do Triângulo',
      icon: <FaPlay className="text-blue-500 text-2xl" />,
      inputs: ['Base', 'Altura'],
      calculate: (values) => (0.5 * values[0] * values[1]).toFixed(2),
    },
    perimeterTriangle: {
      label: 'Perímetro do Triângulo',
      icon: <FaPlay className="text-blue-500 text-2xl" />,
      inputs: ['Lado 1', 'Lado 2', 'Lado 3'],
      calculate: (values) => (values[0] + values[1] + values[2]).toFixed(2),
    },
  };

  const handleInputChange = (index, value) => {
    const newValues = [...values];
    newValues[index] = parseFloat(value) || '';
    setValues(newValues);
  };

  const handleCalculate = () => {
    const { calculate } = calculations[activeCalculation];
    setResult(calculate(values));
  };

  const renderMenu = () => (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-blue-400 to-green-400 text-white">
      <h1 className="text-4xl font-bold mb-8">Geometria</h1>
      <div className="grid grid-cols-1 gap-4">
        {Object.keys(calculations).map((key) => (
          <button
            key={key}
            className="flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={() => {
              setActiveCalculation(key);
              setValues(Array(calculations[key].inputs.length).fill(''));
              setResult('');
            }}
          >
            {calculations[key].icon} {calculations[key].label}
          </button>
        ))}
        <button
          className="flex items-center justify-center bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
          onClick={onBack}
        >
          Voltar ao Menu
        </button>
      </div>
    </div>
  );

  const renderCalculation = () => {
    const { label, inputs, icon } = calculations[activeCalculation];

    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-blue-400 to-green-400 text-white">
        <h1 className="text-3xl font-bold mb-4 flex items-center gap-2">
          {icon} {label}
        </h1>
        <div className="flex flex-col gap-4 mb-4 w-full max-w-md">
          {inputs.map((placeholder, index) => (
            <div key={index} className="flex flex-col items-start">
              <label className="text-lg font-semibold mb-2">{placeholder}</label>
              <input
                type="number"
                className="w-full p-2 border border-gray-300 rounded"
                placeholder={placeholder}
                value={values[index]}
                onChange={(e) => handleInputChange(index, e.target.value)}
              />
            </div>
          ))}
        </div>
        <button
          className="flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4"
          onClick={handleCalculate}
        >
          <FaEquals className="text-white" /> Calcular
        </button>
        <h2 className="text-xl font-bold mb-4">Resultado: {result}</h2>
        <button
          className="flex items-center justify-center bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
          onClick={() => setActiveCalculation(null)}
        >
          Voltar
        </button>
      </div>
    );
  };

  return activeCalculation ? renderCalculation() : renderMenu();
};

export default GeometryCalculations;
