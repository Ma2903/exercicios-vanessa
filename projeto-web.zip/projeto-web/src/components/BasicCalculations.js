import React, { useState } from 'react';
import { FaCalculator, FaTemperatureHigh, FaTemperatureLow, FaEquals } from 'react-icons/fa';

const BasicCalculations = ({ onBack }) => {
  const [activeCalculation, setActiveCalculation] = useState(null);
  const [values, setValues] = useState([]);
  const [result, setResult] = useState('');

  const calculations = {
    average: {
      label: 'Calcular Média',
      icon: <FaCalculator className="text-blue-500 text-2xl" />,
      inputs: ['Nota 1', 'Nota 2', 'Nota 3'],
      calculate: (values) => ((values[0] + values[1] + values[2]) / 3).toFixed(2),
    },
    celsiusToFahrenheit: {
      label: 'Celsius para Fahrenheit',
      icon: <FaTemperatureHigh className="text-blue-500 text-2xl" />,
      inputs: ['Temperatura em Celsius'],
      calculate: (values) => (values[0] * 9 / 5 + 32).toFixed(2),
    },
    fahrenheitToCelsius: {
      label: 'Fahrenheit para Celsius',
      icon: <FaTemperatureLow className="text-blue-500 text-2xl" />,
      inputs: ['Temperatura em Fahrenheit'],
      calculate: (values) => ((values[0] - 32) * 5 / 9).toFixed(2),
    },
  };

  const handleInputChange = (index, value) => {
    const newValues = [...values];
    newValues[index] = parseFloat(value) || '';
    setValues(newValues);
  };

  const handleCalculate = () => {
    const { calculate } = calculations[activeCalculation];
    setResult(calculate(values));
  };

  const renderMenu = () => (
    <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-blue-400 to-green-400 text-white">
      <h1 className="text-4xl font-bold mb-8">Cálculos Básicos</h1>
      <div className="grid grid-cols-1 gap-4">
        {Object.keys(calculations).map((key) => (
          <button
            key={key}
            className="flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            onClick={() => {
              setActiveCalculation(key);
              setValues(Array(calculations[key].inputs.length).fill(''));
              setResult('');
            }}
          >
            {calculations[key].icon} {calculations[key].label}
          </button>
        ))}
        <button
          className="flex items-center justify-center bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
          onClick={onBack}
        >
          Voltar ao Menu
        </button>
      </div>
    </div>
  );

  const renderCalculation = () => {
    const { label, inputs, icon } = calculations[activeCalculation];

    return (
      <div className="flex flex-col items-center justify-center h-screen bg-gradient-to-br from-blue-400 to-green-400 text-white">
        <h1 className="text-3xl font-bold mb-4 flex items-center gap-2">
          {icon} {label}
        </h1>
        <div className="flex flex-col gap-4 mb-4 w-full max-w-md">
          {inputs.map((placeholder, index) => (
            <div key={index} className="flex flex-col items-start">
              <label className="text-lg font-semibold mb-2">{placeholder}</label>
              <input
                type="number"
                className="w-full p-2 border border-gray-300 rounded"
                placeholder={placeholder}
                value={values[index]}
                onChange={(e) => handleInputChange(index, e.target.value)}
              />
            </div>
          ))}
        </div>
        <button
          className="flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mb-4"
          onClick={handleCalculate}
        >
          <FaEquals className="text-white" /> Calcular
        </button>
        <h2 className="text-xl font-bold mb-4">Resultado: {result}</h2>
        <button
          className="flex items-center justify-center bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded"
          onClick={() => setActiveCalculation(null)}
        >
          Voltar
        </button>
      </div>
    );
  };

  return activeCalculation ? renderCalculation() : renderMenu();
};

export default BasicCalculations;
