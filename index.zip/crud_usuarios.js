const conexao = require('./db');
const prompt = require('prompt-sync')();

function criarUsuarios(){
    console.log(conexao);
    console.log('---Criar Usuário---');
    const nome = prompt('Digite o nome do usuário: ');
    const email = prompt('Digite o email do usuário: ');
    const senha = prompt('Digite a senha do usuário: ');

    const sql = `INSERT INTO usuarios (nome, email, senha) 
    VALUES ('${nome}', '${email}', '${senha}')`;

    conexao.query(sql, (err, result) => {
        if(err){
            console.log('Erro ao inserir usuário: '+err);
        }else{
            console.log('Usuário inserido com sucesso!');
        }
    });
}

function listarUsuarios(){
    const sql = 'SELECT * FROM usuarios';

    conexao.query(sql, (err, resp) => {
        if(err){
            console.log('Erro ao buscar usuários: '+err);
            return;
        }
        console.table(resp);
    });
}

function atualizarUsuarios(){
    const id = prompt('Digite o id do usuário: ');
    const nome = prompt('Digite o nome do usuário: ');
    const email = prompt('Digite o email do usuário: ');
    const senha = prompt('Digite a senha do usuário: ');

    const sql = `UPDATE usuarios SET nome='${nome}', email='${email}', senha='${senha}' WHERE id=${id}`;

    conexao.query(sql, [nome, senha, email, id] , (err, result) => {
        if(err){
            console.log('Erro ao atualizar usuário: ' + err);
            return;
        }
        console.log('Usuário atualizado com sucesso!');
    });
}

function deletarUsuarios(){
    const id = prompt('Digite o id do usuário: ');

    const sql = `DELETE FROM usuarios WHERE id=${id}`;

    conexao.query(sql, (err, result) => {
        if(err){
            console.log('Erro ao deletar usuário: '+err);
            return;
        }
        console.log('Usuário deletado com sucesso!');
    });
}

module.exports = {
    criarUsuarios,
    listarUsuarios,
    atualizarUsuarios,
    deletarUsuarios
}