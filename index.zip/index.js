const prompt = require('prompt-sync')();
const { criarUsuarios } = require('./crud_usuarios');

function exibirOpcoes(){
    console.log('---CRUD de Usuarios---');
    console.log('Escolha uma opção: ');
    console.log('1 - Criar usuário');
    console.log('2 - Atualizar usuário');
    console.log('3 - Deletar usuário');
    console.log('4 - Listar usuários');
    console.log('5 - Sair');

    const opcao = prompt('Informe a opção desejada: ');

    switch(opcao){
        case '1':
            criarUsuarios();
            break;
        case '2':
            console.log('Atualizar usuário');
            break;
        case '3':
            console.log('Deletar usuário');
            break;
        case '4':
            console.log('Listar usuários');
            break;
        case '5':
            console.log('Saindo...');
            process.exit();
            break;
        default:
            console.log('Opção inválida');
    }
}

exibirOpcoes();