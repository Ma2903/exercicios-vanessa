import React from "react";
import { Button, Text } from 'react-native-paper';
import { SafeAreaView } from "react-native-safe-area-context";
import { StyleSheet } from "react-native";

export default function Home({ navigation }){
    return (
        <SafeAreaView style={styles.container}>
            <Text>Lista de Exercícios</Text>
            <Button mode="contained" onPress={() => navigation.navigate('Exercicio1')}>
                Abrir Exercício 1
            </Button>
        </SafeAreaView>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
      }
});